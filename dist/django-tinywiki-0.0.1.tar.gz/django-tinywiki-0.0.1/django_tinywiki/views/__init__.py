from .wiki import (
    WikiPageView,
    WikiIndexView,
    WikiCreateView,
    WikiEditView,
    WikiImageUploadView,
)

from . import auth,manage